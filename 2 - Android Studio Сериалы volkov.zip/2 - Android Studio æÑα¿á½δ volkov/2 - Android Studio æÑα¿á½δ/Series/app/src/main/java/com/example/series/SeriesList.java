package com.example.series;

import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class SeriesList {
    List<String> getListTV (String spinner) {
        List<String> list = new ArrayList<>();
        if (spinner.equals("Комедия")) {
            list.add("Друзья");
        }
        if (spinner.equals("Фэнтези")) {
            list.add("Игра Престолов");
        }if (spinner.equals("Хоррор")) {
            list.add("Ходячие мертвецы");
        }if (spinner.equals("Драма")) {
            list.add("Форма голоса");
        }if (spinner.equals("Романтика")) {
            list.add("Твое имя");
            list.add("Город в котором меня нет");
        }
        return list;
    }
}
